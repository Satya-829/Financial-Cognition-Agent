/**
 * gemini.js — AI Client (Proxy Mode)
 * All API calls go through the local Python server at /api/chat.
 * The API key is stored server-side in .env — never exposed to the browser.
 */

const GeminiClient = (() => {
    let currentProvider = '';
    let currentModel = '';
    let connected = false;
    let chatHistory = [];

    /* ─── Provider info (loaded from server) ─── */

    async function init() {
        try {
            const res = await fetch('/api/config');
            if (!res.ok) throw new Error(`Config fetch failed: ${res.status}`);
            const cfg = await res.json();
            currentProvider = cfg.provider || 'groq';
            currentModel = cfg.model || '';
            connected = cfg.connected || false;
            return cfg;
        } catch (e) {
            console.error('Failed to load server config:', e);
            connected = false;
            return { provider: '', model: '', connected: false };
        }
    }

    function getProvider() { return currentProvider; }
    function getModel() { return currentModel; }
    function isConnected() { return connected; }

    /* ─── Chat History ─── */

    function resetChat() {
        chatHistory = [];
    }

    /* ─── Streaming via Proxy ─── */

    const STREAM_TIMEOUT_MS = 120000; // 2 minutes

    async function streamPhase(userMessage, onChunk) {
        if (!connected) throw new Error('API key not configured. Check .env file on the server.');

        // Add user message to history
        chatHistory.push({ role: 'user', content: userMessage });

        // Build the request body based on provider format
        let body;

        if (currentProvider === 'gemini') {
            // Gemini format: contents array
            const contents = chatHistory.map(msg => ({
                role: msg.role === 'assistant' ? 'model' : msg.role,
                parts: [{ text: msg.content }]
            }));
            body = {
                system_instruction: { parts: [{ text: MASTER_PROMPT }] },
                contents,
                generationConfig: { temperature: 0.3, maxOutputTokens: 8192, topP: 0.85 }
            };
        } else {
            // OpenAI format: messages array
            const messages = [
                { role: 'system', content: MASTER_PROMPT },
                ...chatHistory
            ];
            body = {
                messages,
                temperature: 0.3,
                max_tokens: 8192,
                top_p: 0.85
            };
        }

        // Send to proxy
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), STREAM_TIMEOUT_MS);

        let res;
        try {
            res = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
                signal: controller.signal
            });
        } catch (e) {
            clearTimeout(timer);
            chatHistory.pop();
            if (e.name === 'AbortError') throw new Error('Request timed out. Try again.');
            throw e;
        }

        if (!res.ok) {
            clearTimeout(timer);
            chatHistory.pop();
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || `Server returned ${res.status}`);
        }

        // Parse streaming SSE response
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let fullText = '';
        let buffer = '';

        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed.startsWith('data: ')) continue;
                    const jsonStr = trimmed.slice(6).trim();
                    if (!jsonStr || jsonStr === '[DONE]') continue;
                    try {
                        const parsed = JSON.parse(jsonStr);
                        let text = '';
                        if (currentProvider === 'gemini') {
                            text = parsed.candidates?.[0]?.content?.parts?.[0]?.text || '';
                        } else {
                            text = parsed.choices?.[0]?.delta?.content || '';
                        }
                        if (text) {
                            fullText += text;
                            if (onChunk) onChunk(fullText);
                        }
                    } catch (e) { /* skip malformed */ }
                }
            }
        } catch (e) {
            clearTimeout(timer);
            if (e.name === 'AbortError') {
                if (fullText) {
                    console.warn('Stream timed out but partial content received.');
                    chatHistory.push({ role: 'assistant', content: fullText });
                    return fullText;
                }
                throw new Error('Request timed out. Try again.');
            }
            throw e;
        }
        clearTimeout(timer);

        // Process remaining buffer
        if (buffer.trim().startsWith('data: ')) {
            const jsonStr = buffer.trim().slice(6).trim();
            if (jsonStr && jsonStr !== '[DONE]') {
                try {
                    const parsed = JSON.parse(jsonStr);
                    let text = '';
                    if (currentProvider === 'gemini') {
                        text = parsed.candidates?.[0]?.content?.parts?.[0]?.text || '';
                    } else {
                        text = parsed.choices?.[0]?.delta?.content || '';
                    }
                    if (text) {
                        fullText += text;
                        if (onChunk) onChunk(fullText);
                    }
                } catch (e) { /* skip */ }
            }
        }

        chatHistory.push({ role: 'assistant', content: fullText });
        return fullText;
    }

    return {
        init, isConnected, resetChat, streamPhase,
        getProvider, getModel
    };
})();
