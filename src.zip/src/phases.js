/**
 * phases.js — Phase content renderer
 * Renders markdown output from Gemini into phase panels.
 * Handles table styling, streaming cursors, and scenario form logic.
 */

const PhaseRenderer = (() => {

    /**
     * Render markdown text into a phase content element.
     * @param {string} elementId - ID of the content container.
     * @param {string} markdown - Markdown text to render.
     * @param {boolean} streaming - Whether to show streaming cursor.
     */
    function render(elementId, markdown, streaming = false) {
        const el = document.getElementById(elementId);
        if (!el) return;

        let html = '';
        try {
            html = marked.parse(markdown, { breaks: true, gfm: true });
        } catch (e) {
            html = `<pre>${escapeHtml(markdown)}</pre>`;
        }

        // Enhance tables with our CSS classes
        html = html.replace(/<table>/g, '<table class="ratio-table">');

        el.innerHTML = html;

        if (streaming) {
            el.classList.add('streaming-cursor');
        } else {
            el.classList.remove('streaming-cursor');
        }

        // Color-code numeric cells
        el.querySelectorAll('td').forEach(td => {
            const val = parseFloat(td.textContent.replace(/[%,]/g, ''));
            if (!isNaN(val) && td.textContent.match(/[0-9]/)) {
                if (td.textContent.includes('-') || val < 0) {
                    td.classList.add('negative');
                }
            }
        });

        // Auto-scroll to bottom
        el.scrollTop = el.scrollHeight;
    }

    /**
     * Show a message/status inside a phase panel.
     */
    function showMessage(elementId, message, type = 'info') {
        const el = document.getElementById(elementId);
        if (!el) return;
        const colors = {
            info: 'var(--accent-blue)',
            success: 'var(--accent-green)',
            error: 'var(--accent-red)',
            warning: 'var(--accent-gold)'
        };
        el.innerHTML = `<p style="color:${colors[type] || colors.info};font-weight:500;">${message}</p>`;
    }

    /**
     * Show loading skeleton in a phase panel.
     */
    function showLoading(elementId) {
        const el = document.getElementById(elementId);
        if (!el) return;
        el.innerHTML = `
      <div class="loading-skeleton"></div>
      <div class="loading-skeleton" style="margin-top:16px;"></div>
      <div class="loading-skeleton" style="margin-top:16px;"></div>
    `;
    }

    /**
     * Append a chat message to Phase 7.
     */
    function appendChat(role, text) {
        const area = document.getElementById('chatArea');
        if (!area) return;
        const div = document.createElement('div');
        div.className = `chat-msg ${role}`;
        try {
            div.innerHTML = marked.parse(text, { breaks: true, gfm: true });
        } catch {
            div.textContent = text;
        }
        area.appendChild(div);
        area.scrollTop = area.scrollHeight;
    }

    /**
     * Update a streaming chat message (last AI message).
     */
    function updateStreamingChat(text, streaming = true) {
        const area = document.getElementById('chatArea');
        if (!area) return;
        const aiMsgs = area.querySelectorAll('.chat-msg.ai');
        let lastAi = aiMsgs.length ? aiMsgs[aiMsgs.length - 1] : null;
        if (!lastAi) {
            lastAi = document.createElement('div');
            lastAi.className = 'chat-msg ai';
            area.appendChild(lastAi);
        }
        try {
            lastAi.innerHTML = marked.parse(text, { breaks: true, gfm: true });
        } catch {
            lastAi.textContent = text;
        }
        if (streaming) {
            lastAi.classList.add('streaming-cursor');
        } else {
            lastAi.classList.remove('streaming-cursor');
        }
        area.scrollTop = area.scrollHeight;
    }

    function escapeHtml(str) {
        const d = document.createElement('div');
        d.textContent = str;
        return d.innerHTML;
    }

    return { render, showMessage, showLoading, appendChat, updateStreamingChat };
})();
