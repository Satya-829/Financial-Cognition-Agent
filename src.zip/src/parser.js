/**
 * parser.js — File parsing module
 * Accepts CSV / XLSX / XLS and returns normalised JSON.
 * Uses Papa Parse (CSV) and SheetJS (Excel), loaded from CDN.
 */

const FileParser = (() => {

    /**
     * Parse uploaded file. Returns { headers: string[], rows: string[][], raw: string }
     */
    function parse(file) {
        return new Promise((resolve, reject) => {
            const ext = file.name.split('.').pop().toLowerCase();

            if (ext === 'csv') {
                Papa.parse(file, {
                    skipEmptyLines: true,
                    complete(results) {
                        const rows = results.data;
                        if (!rows || rows.length < 2) return reject(new Error('CSV appears empty or has only headers.'));
                        resolve({
                            headers: rows[0],
                            rows: rows.slice(1),
                            raw: Papa.unparse(results.data),
                            fileName: file.name
                        });
                    },
                    error(err) { reject(err); }
                });
            } else if (ext === 'xlsx' || ext === 'xls') {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const workbook = XLSX.read(e.target.result, { type: 'array' });
                        const sheetName = workbook.SheetNames[0];
                        const sheet = workbook.Sheets[sheetName];
                        const json = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
                        if (!json || json.length < 2) return reject(new Error('Spreadsheet appears empty.'));
                        const csv = XLSX.utils.sheet_to_csv(sheet);
                        resolve({
                            headers: json[0].map(String),
                            rows: json.slice(1).map(r => r.map(String)),
                            raw: csv,
                            fileName: file.name
                        });
                    } catch (err) { reject(err); }
                };
                reader.onerror = () => reject(new Error('Failed to read file.'));
                reader.readAsArrayBuffer(file);
            } else {
                reject(new Error(`Unsupported file type: .${ext}`));
            }
        });
    }

    /**
     * Build a preview HTML table (first N rows).
     */
    function previewTable(parsed, maxRows = 12) {
        const { headers, rows } = parsed;
        let html = '<table><thead><tr>';
        headers.forEach(h => { html += `<th>${esc(h)}</th>`; });
        html += '</tr></thead><tbody>';
        const display = rows.slice(0, maxRows);
        display.forEach(row => {
            html += '<tr>';
            row.forEach(cell => { html += `<td>${esc(cell)}</td>`; });
            html += '</tr>';
        });
        if (rows.length > maxRows) {
            html += `<tr><td colspan="${headers.length}" style="text-align:center;color:var(--text-muted);font-style:italic;">… and ${rows.length - maxRows} more rows</td></tr>`;
        }
        html += '</tbody></table>';
        return html;
    }

    function esc(s) {
        const d = document.createElement('div');
        d.textContent = s;
        return d.innerHTML;
    }

    return { parse, previewTable };
})();
