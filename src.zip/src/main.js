/**
 * main.js — App orchestration
 * Wires up event listeners, manages phase transitions,
 * and coordinates file parsing → AI analysis → rendering.
 *
 * API key is handled server-side via .env — no client-side key management.
 * Each phase runs as an INDEPENDENT API call with fresh context.
 */

(function App() {
    'use strict';

    /* ─── State ─── */
    let parsedData = null;
    let currentPhase = 0;
    let analysisRunning = false;

    /** Store phase results so later phases can reference key findings */
    const phaseResults = {};

    /* ─── DOM refs ─── */
    const $ = (sel) => document.querySelector(sel);
    const $$ = (sel) => document.querySelectorAll(sel);

    const uploadZone = $('#uploadZone');
    const fileInput = $('#fileInput');
    const uploadPreview = $('#uploadPreview');
    const previewWrap = $('#previewTableWrap');
    const fileNameBadge = $('#fileName');
    const removeFileBtn = $('#removeFile');
    const startBtn = $('#startAnalysis');
    const resetBtn = $('#resetBtn');
    const chatInput = $('#chatInput');
    const chatSend = $('#chatSend');
    const runScenarioBtn = $('#runScenario');
    const scenarioForm = $('#scenarioForm');

    /* ═══════════════════════════════════════════
       TOAST SYSTEM
       ═══════════════════════════════════════════ */
    function toast(msg, type = 'info', ms = 4000) {
        const container = $('#toastContainer');
        const el = document.createElement('div');
        el.className = `toast ${type}`;
        el.textContent = msg;
        container.appendChild(el);
        setTimeout(() => {
            el.classList.add('exit');
            setTimeout(() => el.remove(), 300);
        }, ms);
    }

    /* ═══════════════════════════════════════════
       SERVER CONFIG — Auto-detect provider/model
       ═══════════════════════════════════════════ */
    const statusBadge = $('#apiKeyStatus');
    const providerLabel = $('#providerLabel');
    const modelLabel = $('#modelLabel');

    async function loadServerConfig() {
        try {
            const cfg = await GeminiClient.init();
            if (providerLabel) providerLabel.textContent = cfg.provider || '—';
            if (modelLabel) modelLabel.textContent = cfg.model || '—';
            if (statusBadge) {
                if (cfg.connected) {
                    statusBadge.textContent = 'Connected';
                    statusBadge.className = 'api-status connected';
                    toast('Server connected — API key loaded from .env', 'success');
                } else {
                    statusBadge.textContent = 'No API Key';
                    statusBadge.className = 'api-status error';
                    toast('API key not set! Edit the .env file on the server.', 'error', 8000);
                }
            }
        } catch (e) {
            if (statusBadge) {
                statusBadge.textContent = 'Server Error';
                statusBadge.className = 'api-status error';
            }
            toast('Cannot reach server. Is server.py running?', 'error', 8000);
        }
    }

    loadServerConfig();

    /* ═══════════════════════════════════════════
       FILE UPLOAD
       ═══════════════════════════════════════════ */
    uploadZone.addEventListener('click', () => fileInput.click());
    uploadZone.addEventListener('dragover', (e) => {
        e.preventDefault(); uploadZone.classList.add('drag-over');
    });
    uploadZone.addEventListener('dragleave', () => {
        uploadZone.classList.remove('drag-over');
    });
    uploadZone.addEventListener('drop', (e) => {
        e.preventDefault(); uploadZone.classList.remove('drag-over');
        if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
    });
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length) handleFile(fileInput.files[0]);
    });
    removeFileBtn.addEventListener('click', clearFile);

    async function handleFile(file) {
        try {
            parsedData = await FileParser.parse(file);
            fileNameBadge.textContent = parsedData.fileName;
            previewWrap.innerHTML = FileParser.previewTable(parsedData);
            uploadPreview.hidden = false;
            uploadZone.style.display = 'none';
            toast(`Loaded ${parsedData.rows.length} rows from ${file.name}`, 'success');
        } catch (err) {
            toast('Parse error: ' + err.message, 'error');
        }
    }

    function clearFile() {
        parsedData = null;
        fileInput.value = '';
        uploadPreview.hidden = true;
        uploadZone.style.display = '';
        previewWrap.innerHTML = '';
    }

    /* ═══════════════════════════════════════════
       PHASE NAVIGATION
       ═══════════════════════════════════════════ */
    function setPhase(idx) {
        currentPhase = idx;
        $$('.phase-step').forEach((btn, i) => {
            btn.classList.remove('active');
            if (i === idx) btn.classList.add('active');
        });
        $$('.phase-panel').forEach(p => p.classList.remove('active'));
        const panel = $(`.phase-panel[data-panel="${idx}"]`);
        if (panel) panel.classList.add('active');
    }

    function markPhase(idx, status) {
        const btn = $(`.phase-step[data-phase="${idx}"]`);
        if (!btn) return;
        btn.classList.remove('completed', 'running');
        if (status) btn.classList.add(status);
    }

    $$('.phase-step').forEach(btn => {
        btn.addEventListener('click', () => {
            const phase = parseInt(btn.dataset.phase);
            setPhase(phase);
        });
    });

    /* ═══════════════════════════════════════════
       HELPER: Truncate text to ~max characters
       ═══════════════════════════════════════════ */
    function truncate(text, maxChars = 1500) {
        if (!text || text.length <= maxChars) return text || '';
        return text.slice(0, maxChars) + '\n\n[...truncated for brevity...]';
    }

    /* ═══════════════════════════════════════════
       ANALYSIS ORCHESTRATION
       Each phase gets a FRESH chat session with only the
       raw data + its own specific prompt.
       ═══════════════════════════════════════════ */
    startBtn.addEventListener('click', runAnalysis);

    async function runAnalysis() {
        if (!parsedData) { toast('Upload a file first.', 'error'); return; }
        if (!GeminiClient.isConnected()) { toast('API key not configured. Edit the .env file.', 'error'); return; }
        if (analysisRunning) return;

        analysisRunning = true;
        startBtn.disabled = true;

        const csvData = parsedData.raw;

        try {
            // ── Phase 1: Data Understanding ──
            GeminiClient.resetChat();
            phaseResults[1] = await runPhase(1, 'phase1Content',
                `Here is the financial data to analyze:\n\n\`\`\`csv\n${csvData}\n\`\`\`\n\nPlease begin Phase 1: Data Understanding. Identify which statements are present and map all line items.`
            );

            // Small delay to avoid rate limiting
            await new Promise(r => setTimeout(r, 2000));

            // ── Phase 2: Ratio Engine ──
            GeminiClient.resetChat();
            phaseResults[2] = await runPhase(2, 'phase2Content',
                `Here is the financial data:\n\n\`\`\`csv\n${csvData}\n\`\`\`\n\nProceed to Phase 2: Ratio Engine. Calculate all ratios (Liquidity, Leverage, Profitability, Efficiency, Cash Strength) with explicit formulas in table format. Do not interpret yet.`
            );

            // Small delay to avoid rate limiting
            await new Promise(r => setTimeout(r, 2000));

            // ── Phase 3: Trend Analysis ──
            GeminiClient.resetChat();
            phaseResults[3] = await runPhase(3, 'phase3Content',
                `Here is the financial data:\n\n\`\`\`csv\n${csvData}\n\`\`\`\n\nProceed to Phase 3: Trend Analysis. Show growth rates and % change calculations for Revenue, Net Income, margins, and leverage for all available years.`
            );

            // Small delay to avoid rate limiting
            await new Promise(r => setTimeout(r, 2000));

            // ── Phase 4: Analyst Interpretation ──
            GeminiClient.resetChat();
            phaseResults[4] = await runPhase(4, 'phase4Content',
                `Here is the financial data:\n\n\`\`\`csv\n${csvData}\n\`\`\`\n\nHere is a summary of the ratio analysis:\n${truncate(phaseResults[2], 2000)}\n\nHere is a summary of trend analysis:\n${truncate(phaseResults[3], 1500)}\n\nProceed to Phase 4: Senior Equity Analyst Interpretation Mode. Cover all 7 structured sections: Business Quality, Profitability Health, Financial Stability, Cash Flow Sustainability, Growth Momentum, Red Flags, Competitive Positioning.`
            );

            // ── Phase 5: Scenario Simulation — show form ──
            setPhase(5);
            markPhase(5, 'running');
            scenarioForm.hidden = false;
            PhaseRenderer.showMessage('scenarioResult', 'Enter your scenario assumptions above and click "Run Projection".', 'info');
            markPhase(5, 'completed');

        } catch (err) {
            toast('Analysis error: ' + err.message, 'error', 6000);
        } finally {
            analysisRunning = false;
            startBtn.disabled = false;
        }
    }

    async function runPhase(phaseIdx, contentId, prompt, retries = 2) {
        setPhase(phaseIdx);
        markPhase(phaseIdx, 'running');
        PhaseRenderer.showLoading(contentId);

        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                if (attempt > 0) {
                    PhaseRenderer.showMessage(contentId, `Retrying Phase ${phaseIdx} (attempt ${attempt + 1})…`, 'warning');
                    await new Promise(r => setTimeout(r, 3000 * attempt));
                }

                const fullText = await GeminiClient.streamPhase(prompt, (partial) => {
                    PhaseRenderer.render(contentId, partial, true);
                });

                PhaseRenderer.render(contentId, fullText, false);
                markPhase(phaseIdx, 'completed');
                return fullText;
            } catch (err) {
                if (attempt < retries) {
                    console.warn(`Phase ${phaseIdx} failed (attempt ${attempt + 1}), retrying:`, err.message);
                    toast(`Phase ${phaseIdx} failed, retrying…`, 'warning');
                    GeminiClient.resetChat();
                    continue;
                }
                markPhase(phaseIdx, '');
                throw err;
            }
        }
    }

    /* ═══════════════════════════════════════════
       SCENARIO SIMULATION (Phase 5 → 6 → 7)
       ═══════════════════════════════════════════ */
    runScenarioBtn.addEventListener('click', async () => {
        if (!GeminiClient.isConnected()) { toast('API key not configured. Edit the .env file.', 'error'); return; }

        const revGrowth = $('#scenRevGrowth').value;
        const opMargin = $('#scenOpMargin').value;
        const capex = $('#scenCapex').value;
        const taxRate = $('#scenTaxRate').value;
        const wacc = $('#scenWACC').value;

        const csvData = parsedData ? parsedData.raw : '';

        // ── Phase 5: Scenario with fresh context ──
        GeminiClient.resetChat();
        const scenarioPrompt = `Here is the financial data:\n\n\`\`\`csv\n${csvData}\n\`\`\`\n\nProceed to Phase 5: Scenario Driver Simulation with these assumptions:
- Revenue Growth: ${revGrowth}%
- Operating Margin: ${opMargin}%
- Capex as % of Revenue: ${capex}%
- Tax Rate: ${taxRate}%
- WACC: ${wacc}%

Project 3-year forecast. Present projected Revenue, EBIT, Net Income, and Free Cash Flow. Clearly separate assumptions from historical data.`;

        runScenarioBtn.disabled = true;
        runScenarioBtn.textContent = 'Running…';
        PhaseRenderer.showLoading('scenarioResult');

        try {
            const result = await GeminiClient.streamPhase(scenarioPrompt, (partial) => {
                PhaseRenderer.render('scenarioResult', partial, true);
            });
            PhaseRenderer.render('scenarioResult', result, false);
            phaseResults[5] = result;
            markPhase(5, 'completed');

            // ── Phase 6: Investment Memo — FRESH context ──
            GeminiClient.resetChat();
            const memoPrompt = `You are a Senior Equity Analyst writing an Investment Research Memo.

Here is the financial data:

\`\`\`csv
${csvData}
\`\`\`

Key analysis findings:

**Ratio Analysis (summary):**
${truncate(phaseResults[2], 1500)}

**Analyst Interpretation (summary):**
${truncate(phaseResults[4], 1500)}

**Scenario Projection (summary):**
${truncate(result, 1000)}

Now generate the structured Investment Research Memo with the following sections:
1. Executive Summary
2. Bull Case
3. Bear Case
4. Key Risks
5. Sensitivity Factors
6. Preliminary Investment View (Not Financial Advice)

Keep language professional, structured, and easy to understand.`;

            phaseResults[6] = await runPhase(6, 'phase6Content', memoPrompt);

            // ── Phase 7: Deep Dive — ready
            setPhase(7);
            markPhase(7, 'running');
            GeminiClient.resetChat();
            PhaseRenderer.appendChat('ai', 'Analysis complete. Would you like deeper analysis on **valuation**, **industry context**, or **macro impact**? Feel free to ask any follow-up question.');
            markPhase(7, 'completed');

        } catch (err) {
            toast('Error: ' + err.message, 'error', 6000);
        } finally {
            runScenarioBtn.disabled = false;
            runScenarioBtn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg> Run Projection';
        }
    });

    /* ═══════════════════════════════════════════
       DEEP DIVE CHAT (Phase 7)
       ═══════════════════════════════════════════ */
    chatSend.addEventListener('click', sendChat);
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
    });

    async function sendChat() {
        const text = chatInput.value.trim();
        if (!text || !GeminiClient.isConnected()) return;

        chatInput.value = '';
        PhaseRenderer.appendChat('user', text);

        // If first chat, seed context
        if (!phaseResults._chatSeeded && parsedData) {
            const csvData = parsedData.raw;
            const seedContext = `Context: Here is the financial data:\n\`\`\`csv\n${csvData}\n\`\`\`\n\nInvestment Memo summary:\n${truncate(phaseResults[6], 1500)}\n\nThe user wants to do a deep dive. Answer their question:\n${text}`;
            phaseResults._chatSeeded = true;

            try {
                await GeminiClient.streamPhase(seedContext, (partial) => {
                    PhaseRenderer.updateStreamingChat(partial, true);
                });
                const area = $('#chatArea');
                const aiMsgs = area.querySelectorAll('.chat-msg.ai');
                const lastAi = aiMsgs.length ? aiMsgs[aiMsgs.length - 1] : null;
                if (lastAi) lastAi.classList.remove('streaming-cursor');
            } catch (err) {
                PhaseRenderer.appendChat('ai', '⚠️ Error: ' + err.message);
            }
            return;
        }

        try {
            await GeminiClient.streamPhase(text, (partial) => {
                PhaseRenderer.updateStreamingChat(partial, true);
            });
            const area = $('#chatArea');
            const aiMsgs = area.querySelectorAll('.chat-msg.ai');
            const lastAi = aiMsgs.length ? aiMsgs[aiMsgs.length - 1] : null;
            if (lastAi) lastAi.classList.remove('streaming-cursor');
        } catch (err) {
            PhaseRenderer.appendChat('ai', '⚠️ Error: ' + err.message);
        }
    }

    /* ═══════════════════════════════════════════
       RESET
       ═══════════════════════════════════════════ */
    resetBtn.addEventListener('click', () => {
        clearFile();
        GeminiClient.resetChat();
        Object.keys(phaseResults).forEach(k => delete phaseResults[k]);
        setPhase(0);
        $$('.phase-step').forEach(btn => {
            btn.classList.remove('completed', 'running');
        });
        for (let i = 1; i <= 6; i++) {
            const el = $(`#phase${i}Content`);
            if (el) el.innerHTML = '<div class="loading-skeleton"></div>';
        }
        $('#chatArea').innerHTML = '';
        scenarioForm.hidden = true;
        $('#scenarioResult').innerHTML = '';
        toast('Analysis reset.', 'info');
    });

    /* ─── Init ─── */
    setPhase(0);

})();
